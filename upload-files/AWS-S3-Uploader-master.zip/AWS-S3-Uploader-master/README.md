# AWS-S3-Uploader

Direct Upload to Amazon AWS S3 Using PHP & HTML

Tutorial : http://www.sanwebe.com/2015/09/direct-upload-to-amazon-aws-s3-using-php-html

License : http://opensource.org/licenses/MIT
